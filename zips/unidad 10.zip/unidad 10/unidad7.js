//formulario de datos personales

/*
    var nombreCompleto = prompt("Ingrese su nombre completo:");
    var edad = prompt("ingrese su edad:");
    var localidad = prompt("ingrese su localidad:");
    var mail = prompt("ingrese su mail:");
    var intereses = prompt("¿Que es lo que lo/la trae a este sitio?", "ej: entrenamiento");
 */





